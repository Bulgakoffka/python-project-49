### Hexlet tests and linter status:
[![Actions Status](https://github.com/Bulgakoffka/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Bulgakoffka/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/cc48e2221afe26476e02/maintainability)](https://codeclimate.com/github/Bulgakoffka/python-project-49/maintainability)